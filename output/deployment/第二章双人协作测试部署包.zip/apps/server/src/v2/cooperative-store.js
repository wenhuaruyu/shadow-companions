import { createHash } from 'node:crypto';
export function cooperativeStore(rooms) {
  return {
    enter: (...args) => rooms.enter(...args),
    loadGame: (...args) => rooms.loadGame(...args),
    commitGame(document, token, rewards, requestId, payload) {
      const digest = createHash('sha256').update(token).digest('hex');
      if (typeof rooms.call === 'function') {
        return rooms.call('anxian_game_reward_commit', {
          p_room: document.id, p_token_hash: digest, p_version: document.version,
          p_state: document.state, p_rewards: rewards,
          p_request_id: requestId ?? null, p_payload: payload ?? null,
        });
      }
      return rooms.gameQuery('SELECT public.anxian_game_reward_commit($1,$2,$3,$4,$5,$6,$7) AS result',
        [document.id, digest, document.version, JSON.stringify(document.state), JSON.stringify(rewards), requestId ?? null, payload ?? null]);
    },
  };
}
